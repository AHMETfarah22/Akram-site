// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
  // Initialize AOS animation library
  AOS.init({
    duration: 800,
    easing: 'ease',
    once: true,
    offset: 100
  });

  // Mobile menu toggle
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");
  
  navToggle.addEventListener("click", () => {
    navToggle.classList.toggle("active");
    navLinks.classList.toggle("active");
  });

  // Close mobile menu when clicking outside
  document.addEventListener('click', (e) => {
    if (!navToggle.contains(e.target) && !navLinks.contains(e.target) && navLinks.classList.contains('active')) {
      navToggle.classList.remove("active");
      navLinks.classList.remove("active");
    }
  });

  // Dark mode toggle
  const darkSwitch = document.getElementById('dark-mode-switch');
  
  // Load dark mode state on page load
  const savedDarkMode = localStorage.getItem('darkMode') === 'true';
  darkSwitch.checked = savedDarkMode;
  document.body.classList.toggle('dark-mode', savedDarkMode);
  
  // Toggle dark mode when switch is clicked
  darkSwitch.addEventListener('change', () => {
    document.body.classList.toggle('dark-mode', darkSwitch.checked);
    localStorage.setItem('darkMode', darkSwitch.checked);
  });

  // Language Switch functionality
  const languageSwitch = document.getElementById('language-switch');
  
  // Load saved language preference
  const savedLanguage = localStorage.getItem('language') || 'tr';
  languageSwitch.value = savedLanguage;
  
  // Translations object
  const translations = {
    tr: {
      home: 'Anasayfa',
      about: 'Hakkımda',
      services: 'Hizmetler',
      projects: 'Projeler',
      contact: 'İletişim',
      intro: 'HI, Iam',
      subtitle: 'Full Stack Developer & UI/UX Designer',
      description: 'Bilgisayar Mühendisliği ve Programlama alanında uzmanlaşmış, modern, mobil uyumlu ve kullanıcı dostu dijital çözümler üreten bir geliştiriciyim.',
      emailBtn: 'E-posta Gönder',
      phoneBtn: 'Telefonla Ara',
      aboutTitle: 'Hakkımda',
      fullName: 'Adı Soyadı',
      education: 'Eğitim',
      experience: 'Çalışma Deneyimi',
      skills: 'Beceriler',
      servicesTitle: 'Hizmetlerim',
      projectsTitle: 'Projelerim',
      viewProject: 'Projeyi Görüntüle',
      contactTitle: 'İletişim',
      name: 'Adınız',
      email: 'E-posta',
      subject: 'Konu',
      message: 'Mesajınız',
      send: 'Gönder',
      selectSubject: 'Konu Seçin',
      webDev: 'Web Sitesi Geliştirme',
      uiuxDesign: 'UI/UX Tasarımı',
      consulting: 'Danışmanlık',
      other: 'Diğer',
      location: 'Konum'
    },
    en: {
      home: 'Home',
      about: 'About',
      services: 'Services',
      projects: 'Projects',
      contact: 'Contact',
      intro: 'HI, I am',
      subtitle: 'Full Stack Developer & UI/UX Designer',
      description: 'I am a developer specialized in Computer Engineering and Programming, creating modern, mobile-friendly and user-friendly digital solutions.',
      emailBtn: 'Send Email',
      phoneBtn: 'Call Phone',
      aboutTitle: 'About Me',
      fullName: 'Full Name',
      education: 'Education',
      experience: 'Work Experience',
      skills: 'Skills',
      servicesTitle: 'My Services',
      projectsTitle: 'My Projects',
      viewProject: 'View Project',
      contactTitle: 'Contact',
      name: 'Your Name',
      email: 'Email',
      subject: 'Subject',
      message: 'Your Message',
      send: 'Send',
      selectSubject: 'Select Subject',
      webDev: 'Website Development',
      uiuxDesign: 'UI/UX Design',
      consulting: 'Consulting',
      other: 'Other',
      location: 'Location'
    }
  };

  languageSwitch.addEventListener('change', (e) => {
    const lang = e.target.value;
    localStorage.setItem('language', lang);
    
    // Simple language switch notification
    const message = lang === 'tr' ? 'Dil Türkçe olarak değiştirildi.' : 'Language changed to English.';
    
    // Create and show notification
    const notification = document.createElement('div');
    notification.className = 'language-notification';
    notification.textContent = message;
    notification.style.position = 'fixed';
    notification.style.top = '80px';
    notification.style.right = '20px';
    notification.style.background = '#0077cc';
    notification.style.color = 'white';
    notification.style.padding = '10px 20px';
    notification.style.borderRadius = '5px';
    notification.style.zIndex = '1000';
    notification.style.boxShadow = '0 3px 10px rgba(0,0,0,0.2)';
    notification.style.opacity = '0';
    notification.style.transition = 'opacity 0.3s ease';
    
    document.body.appendChild(notification);
    
    // Fade in
    setTimeout(() => {
      notification.style.opacity = '1';
    }, 10);
    
    // Remove after 3 seconds
    setTimeout(() => {
      notification.style.opacity = '0';
      setTimeout(() => {
        document.body.removeChild(notification);
      }, 300);
    }, 3000);
    
    // Implement language translation
    translateContent(lang);
  });
  
  // Function to translate content
  function translateContent(lang) {
    const t = translations[lang];
    
    // Translate navigation
    document.querySelectorAll('.nav-link').forEach(link => {
      const key = link.getAttribute('href').substring(1);
      if (key === 'home') link.innerHTML = `<i class="fas fa-home"></i> ${t.home}`;
      if (key === 'about') link.innerHTML = `<i class="fas fa-user"></i> ${t.about}`;
      if (key === 'services') link.innerHTML = `<i class="fas fa-cogs"></i> ${t.services}`;
      if (key === 'projects') link.innerHTML = `<i class="fas fa-briefcase"></i> ${t.projects}`;
      if (key === 'contact') link.innerHTML = `<i class="fas fa-envelope"></i> ${t.contact}`;
    });
    
    // Translate home section
    const introHeading = document.querySelector('.intro-heading');
    if (introHeading) {
      introHeading.innerHTML = `${t.intro} <span class="highlight">Ahmed Farah</span>`;
    }
    
    const subtitle = document.querySelector('.subtitle');
    if (subtitle) subtitle.textContent = t.subtitle;
    
    const description = document.querySelector('.description');
    if (description) description.textContent = t.description;
    
    // Translate buttons
    const emailBtn = document.querySelector('.btn-primary');
    if (emailBtn) emailBtn.innerHTML = `<i class="fas fa-envelope"></i> ${t.emailBtn}`;
    
    const phoneBtn = document.querySelector('.btn-secondary');
    if (phoneBtn) phoneBtn.innerHTML = `<i class="fas fa-phone"></i> ${t.phoneBtn}`;
    
    // Translate section titles
    document.querySelectorAll('.section-title').forEach(title => {
      if (title.closest('#about')) title.textContent = t.aboutTitle;
      if (title.closest('#services')) title.textContent = t.servicesTitle;
      if (title.closest('#projects')) title.textContent = t.projectsTitle;
      if (title.closest('#contact')) title.textContent = t.contactTitle;
    });
    
    // Translate about section
    const aboutItems = document.querySelectorAll('.about-item strong');
    aboutItems.forEach(item => {
      if (item.innerHTML.includes('Adı Soyadı')) {
        item.innerHTML = `<i class="fas fa-user"></i> ${t.fullName}:`;
      }
      if (item.innerHTML.includes('Eğitim')) {
        item.innerHTML = `<i class="fas fa-graduation-cap"></i> ${t.education}:`;
      }
      if (item.innerHTML.includes('Çalışma Deneyimi')) {
        item.innerHTML = `<i class="fas fa-briefcase"></i> ${t.experience}:`;
      }
    });
    
    // Translate skills subtitle
    const skillsSubtitle = document.querySelector('.about-subtitle');
    if (skillsSubtitle) skillsSubtitle.innerHTML = `<i class="fas fa-tools"></i> ${t.skills}`;
    
    // Translate view project buttons
    document.querySelectorAll('.view-project-btn').forEach(btn => {
      btn.textContent = t.viewProject;
    });
    
    // Translate contact form
    const formLabels = document.querySelectorAll('.form-group label');
    formLabels.forEach(label => {
      if (label.textContent === 'Adınız') label.textContent = t.name;
      if (label.textContent === 'E-posta') label.textContent = t.email;
      if (label.textContent === 'Konu') label.textContent = t.subject;
      if (label.textContent === 'Mesajınız') label.textContent = t.message;
    });
    
    // Translate form placeholders
    document.getElementById('name').placeholder = lang === 'tr' ? 'Adınızı girin' : 'Enter your name';
    document.getElementById('email').placeholder = lang === 'tr' ? 'E-posta adresinizi girin' : 'Enter your email';
    document.getElementById('message').placeholder = lang === 'tr' ? 'Mesajınızı yazın' : 'Write your message';
    
    // Translate subject options
    const subjectOptions = document.querySelectorAll('#subject option');
    subjectOptions.forEach(option => {
      if (option.value === '') option.textContent = t.selectSubject;
      if (option.value === 'website') option.textContent = t.webDev;
      if (option.value === 'uiux') option.textContent = t.uiuxDesign;
      if (option.value === 'consulting') option.textContent = t.consulting;
      if (option.value === 'other') option.textContent = t.other;
    });
    
    // Translate send button
    const sendBtn = document.querySelector('.contact-form button[type="submit"]');
    if (sendBtn) sendBtn.textContent = t.send;
    
    // Translate contact info
    const contactInfo = document.querySelectorAll('.contact-info p strong');
    contactInfo.forEach(info => {
      if (info.textContent === 'Konum:') info.textContent = `${t.location}:`;
    });
  }
  
  // Apply translation on page load
  translateContent(savedLanguage);

  // Active menu link highlighting
  const sections = document.querySelectorAll('section[id]');
  const navItems = document.querySelectorAll('.nav-link');
  
  // Smooth scroll for navigation links
  navItems.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Get the target section
      const targetId = this.getAttribute('href');
      const targetSection = document.querySelector(targetId);
      
      // Scroll to the section
      window.scrollTo({
        top: targetSection.offsetTop - 70,
        behavior: 'smooth'
      });
      
      // Close mobile menu if open
      if (navLinks.classList.contains('active')) {
        navToggle.classList.remove("active");
        navLinks.classList.remove("active");
      }
      
      // Update active link
      navItems.forEach(item => item.classList.remove('active'));
      this.classList.add('active');
    });
  });
  
  // Update active menu item on scroll
  function highlightNavOnScroll() {
    const scrollPosition = window.scrollY + 100;
    
    sections.forEach(section => {
      const sectionTop = section.offsetTop - 100;
      const sectionHeight = section.offsetHeight;
      const sectionId = section.getAttribute('id');
      
      if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
        navItems.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === '#' + sectionId) {
            link.classList.add('active');
          }
        });
      }
    });
  }
  
  window.addEventListener('scroll', highlightNavOnScroll);
  
  // Initialize active link on page load
  highlightNavOnScroll();

  // Skills progress bar animation
  const skills = document.querySelectorAll('.core-competencies .skill');
  
  function animateSkills() {
    skills.forEach(skill => {
      const percent = skill.getAttribute('data-percent');
      const progressBar = skill.querySelector('.progress');
      progressBar.style.width = percent + '%';
    });
  }
  
  // Animate skills when they come into view
  const skillsSection = document.querySelector('.skills-section');
  
  const skillsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateSkills();
        skillsObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });
  
  if (skillsSection) {
    skillsObserver.observe(skillsSection);
  }

  // Tooltip functionality for tech items
  const tooltip = document.getElementById('tooltip');
  const techItems = document.querySelectorAll('.tech-list li');
  
  if (tooltip && techItems.length > 0) {
    techItems.forEach(item => {
      item.addEventListener('mouseenter', (e) => {
        const tip = item.getAttribute('data-tooltip');
        tooltip.textContent = tip;
        tooltip.style.opacity = '1';
        
        // Position tooltip near the item
        positionTooltip(e);
      });
      
      item.addEventListener('mousemove', (e) => {
        positionTooltip(e);
      });
      
      item.addEventListener('mouseleave', () => {
        tooltip.style.opacity = '0';
      });
    });
  }
  
  function positionTooltip(e) {
    const x = e.clientX;
    const y = e.clientY;
    
    // Check if tooltip would go off screen to the right
    const tooltipWidth = tooltip.offsetWidth;
    const windowWidth = window.innerWidth;
    
    if (x + tooltipWidth + 20 > windowWidth) {
      tooltip.style.left = (x - tooltipWidth - 10) + 'px';
    } else {
      tooltip.style.left = (x + 15) + 'px';
    }
    
    tooltip.style.top = (y + 15) + 'px';
  }

  // Project modal functionality
  const modal = document.getElementById('projectModal');
  const modalTitle = document.getElementById('modal-title');
  const modalDesc = document.getElementById('modal-description');
  const modalImg = document.getElementById('modal-image');
  const closeBtn = document.querySelector('.close-btn');
  const projectButtons = document.querySelectorAll('.view-project-btn');
  
  if (modal && projectButtons.length > 0) {
    // Open modal when project button is clicked
    projectButtons.forEach(button => {
      button.addEventListener('click', () => {
        const card = button.closest('.project-card');
        const title = card.getAttribute('data-title');
        const desc = card.getAttribute('data-desc');
        const imgSrc = card.getAttribute('data-image');
        
        modalTitle.textContent = title;
        modalDesc.textContent = desc;
        modalImg.src = imgSrc;
        modalImg.alt = title;
        
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden'; // Prevent scrolling when modal is open
      });
    });
    
    // Close modal when X button is clicked
    closeBtn.addEventListener('click', () => {
      closeModal();
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeModal();
      }
    });
    
    // Close modal with ESC key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.style.display === 'flex') {
        closeModal();
      }
    });
    
    function closeModal() {
      modal.style.display = 'none';
      document.body.style.overflow = ''; // Restore scrolling
    }
  }

  // Contact form validation and submission
  const contactForm = document.getElementById('contactForm');
  const formMessage = document.getElementById('form-message');
  
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      // Get form fields
      const name = contactForm.name.value.trim();
      const email = contactForm.email.value.trim();
      const subject = contactForm.subject.value.trim();
      const message = contactForm.message.value.trim();
      
      // Validate form
      if (name === '' || email === '' || subject === '' || message === '') {
        showFormMessage('Lütfen tüm alanları doldurun.', 'error');
        return;
      }
      
      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        showFormMessage('Geçerli bir e-posta adresi girin.', 'error');
        return;
      }
      
      // If using EmailJS
      if (typeof emailjs !== 'undefined') {
        // Show loading message
        showFormMessage('Mesajınız gönderiliyor...', 'info');
        
        emailjs.sendForm('service_6to00op', 'template_io1fop6', contactForm)
          .then(function() {
            showFormMessage('Mesaj başarıyla gönderildi!', 'success');
            contactForm.reset();
          }, function(error) {
            showFormMessage('Hata oluştu: ' + error.text, 'error');
          });
      } else {
        // Fallback if EmailJS is not available
        showFormMessage('Mesaj gönderme servisi şu anda kullanılamıyor.', 'error');
      }
    });
  }
  
  function showFormMessage(text, type) {
    if (!formMessage) return;
    
    formMessage.textContent = text;
    
    // Set color based on message type
    switch (type) {
      case 'success':
        formMessage.style.color = '#28a745';
        break;
      case 'error':
        formMessage.style.color = '#dc3545';
        break;
      case 'info':
        formMessage.style.color = '#17a2b8';
        break;
      default:
        formMessage.style.color = '#333';
    }
    
    // Clear message after 5 seconds if it's a success message
    if (type === 'success') {
      setTimeout(() => {
        formMessage.textContent = '';
      }, 5000);
    }
  }
});
