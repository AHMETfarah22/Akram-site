const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

// POST endpoint for contact form
app.post('/contact', async (req, res) => {
  const { name, email, subject, message } = req.body;

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'dedeyare4455@gmail.com',
      pass: 'Muhubo1122@' // Gmail için "Uygulama Şifresi" kullanmalısın
    }
  });

  const mailOptions = {
    from: email,
    to: 'your-email@gmail.com',
    subject: `Mesaj: ${subject}`,
    text: `Ad: ${name}\nEmail: ${email}\nMesaj: ${message}`
  };

  try {
    await transporter.sendMail(mailOptions);
    res.status(200).send('Mesaj gönderildi');
  } catch (error) {
    console.error(error);
    res.status(500).send('Gönderim hatası');
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
